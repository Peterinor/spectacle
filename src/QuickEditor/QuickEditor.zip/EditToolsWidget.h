/*
 *  Copyright (C) 2016 Boudhayan Gupta <bgupta@kde.org>
 *  Copyright (C) 2018 Ambareesh "Amby" Balaji <ambareeshbalaji@gmail.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor,
 *  Boston, MA 02110-1301, USA.
 */

#ifndef EDITTOOLWIDGET_H
#define EDITTOOLWIDGET_H

#include <QKeyEvent>
#include <QPainter>
#include <QStaticText>
#include <QWidget>
#include <QScreen>
#include <QGuiApplication>
#include <utility>
#include <vector>

#include <QDialogButtonBox>
#include <QToolButton>
#include <QVBoxLayout>

#include <QStack>

#include "QuickEditor.h"

class QMouseEvent;
class QuickEditor;

class EditToolsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit EditToolsWidget(QuickEditor* editor, const QPixmap& pixmap);

    enum EditToolState : short {
        NoEdit = 0,
        DrawLine,
        DrawArrow,
        DrawRect,
        DrawCircle,
        DrawText
    };

    EditToolState toolsState() {
        return this->mEditToolState;
    }

private:
    void toggleDrawLine();
    void toggleDrawArrow();
    void toggleDrawRect();
    void toggleDrawCircle();
    void toggleDrawText();
    void toggleDrawState(EditToolState state);

    void addEditToolButton(QDialogButtonBox * box, const char * name, const char * toolTip, void (EditToolsWidget::*fn)());
    void drawElements(QPainter &pt);
    void undo();

    QuickEditor *mEditor;

    QStack<QPixmap> *history;
    QLineF mLine;
    QRectF mRect;

    EditToolState mEditToolState;

    QDialogButtonBox *mDialogButtonBox;
    QVBoxLayout      *mLayout;
};

#endif // EDITTOOLWIDGET_H
