/*
 *  Copyright (C) 2016 Boudhayan Gupta <bgupta@kde.org>
 *  Copyright (C) 2018 Ambareesh "Amby" Balaji <ambareeshbalaji@gmail.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor,
 *  Boston, MA 02110-1301, USA.
 */

#include <QAction>
#include <KLocalizedString>

#include "EditToolsWidget.h"
#include "SpectacleConfig.h"

#include <QtGui>
#include <QInputDialog>


EditToolsWidget::EditToolsWidget(QuickEditor* editor, const QPixmap& pixmap) :
    history(new QStack<QPixmap>()),

    mEditor(editor),
    mDialogButtonBox(new QDialogButtonBox(this)),
    mLayout(new QVBoxLayout(this))
{
    this->showEditTools(false);

    //mDialogButtonBox->setFixedSize(300, 50);
    mDialogButtonBox->setCursor(Qt::ArrowCursor);
    mDialogButtonBox->setCenterButtons(false);

    this->addEditToolButton(mDialogButtonBox, "－", "Draw Line.",  &EditToolsWidget::toggleDrawLine);
    this->addEditToolButton(mDialogButtonBox, "→", "Draw Arrow.", &EditToolsWidget::toggleDrawArrow);
    this->addEditToolButton(mDialogButtonBox, "□", "Draw Rect.", &EditToolsWidget::toggleDrawRect);
    this->addEditToolButton(mDialogButtonBox, "○", "Draw circle.", &EditToolsWidget::toggleDrawCircle);
    this->addEditToolButton(mDialogButtonBox, "Ａ", "Draw Text.", &EditToolsWidget::toggleDrawText);
    this->addEditToolButton(mDialogButtonBox, "Ｕ", "undo.", &EditToolsWidget::undo);
    this->addEditToolButton(mDialogButtonBox, "OK", "OK.", &EditToolsWidget::acceptSelection);
    this->addEditToolButton(mDialogButtonBox, "×", "Cancel.", &EditToolsWidget::grabCancelled);

    QDialogButtonBox * mDialogButtonBox2 = new QDialogButtonBox(this);
    this->addEditToolButton(mDialogButtonBox, "×", "Cancel.", &EditToolsWidget::grabCancelled);

    mLayout->addWidget(mDialogButtonBox);
    mLayout->insertSpacing(3, 100);
    mLayout->addWidget(mDialogButtonBox2);
    //mDialogButtonBox->setBackgroundRole(QPalette::ColorRole::Dark);
    //mDialogButtonBox->setAutoFillBackground(true);
}

void EditToolsWidget::showEditTools(bool show) {
    if(show) {
        qreal left = mSelection.x();
        qreal top = mSelection.y() + mSelection.height();
        int width = static_cast<int>(mSelection.width());
        if(width < 200) {
            width = 200;
        }
        mDialogButtonBox->setFixedWidth(width);

        //qDebug() << mDialogButtonBox->width() << ";" << mDialogButtonBox->height() << endl;
        mDialogButtonBox->move(static_cast<int>(left), static_cast<int>(top));
        mDialogButtonBox->show();
    } else {
        mDialogButtonBox->hide();
    }
}


void EditToolsWidget::toggleDrawState(EditToolState status) {
    if(this->mEditToolState == status) {
        this->mEditToolState = EditToolState::NoEdit;
    } else {
        this->mEditToolState = status;
    }
    //qDebug() << this->mEditToolState << endl;
}

void EditToolsWidget::toggleDrawLine() {
    this->toggleDrawState(EditToolState::DrawLine);
}

void EditToolsWidget::toggleDrawArrow() {
    this->toggleDrawState(EditToolState::DrawArrow);
}

void EditToolsWidget::toggleDrawRect() {
    this->toggleDrawState(EditToolState::DrawRect);
}

void EditToolsWidget::toggleDrawCircle() {
    this->toggleDrawState(EditToolState::DrawCircle);
}

void EditToolsWidget::toggleDrawText() {
    this->toggleDrawState(EditToolState::DrawText);
}

void EditToolsWidget::addEditToolButton(QDialogButtonBox* box, const char *name, const char *toolTip, void (EditToolsWidget::*fn)()) {
    QToolButton *editButton = new QToolButton(this);
    editButton->setToolTip(i18n(toolTip));
    QAction *editButtonAction = new QAction(i18n(name), this);
    connect(editButtonAction, &QAction::triggered, this, fn);
    editButton->setDefaultAction(editButtonAction);
    box->addButton(editButton, QDialogButtonBox::ActionRole);
}


void EditToolsWidget::drawElements(QPainter &pt) {
    pt.setBrush(Qt::NoBrush);
    pt.setRenderHint(QPainter::Antialiasing, true);
    QPen pen;
    pen.setWidth(2);
    pen.setColor(QColor(255, 0 , 0));
    pen.setCapStyle(Qt::RoundCap);
    pen.setJoinStyle(Qt::RoundJoin);
    pt.setPen(pen);
    switch(this->mEditToolState) {
        case EditToolState::DrawLine:
            pt.drawLine(this->mLine);
            break;
        case EditToolState::DrawRect:
            pt.drawRect(this->mRect);
            break;
        case EditToolState::DrawCircle:
            pt.drawEllipse(this->mRect);
            break;
        default:
            break;
    }
}

void EditToolsWidget::undo() {
    this->mEditToolState = EditToolState::NoEdit;
    if(this->history->size()) {
        this->mPixmap = this->history->pop();
    }
    update();
}